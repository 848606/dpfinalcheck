package AbstractFactory;

public class Agent extends Channel {

	public String toString() {
		return "ChannelType :: Agent";
	}
	

}
